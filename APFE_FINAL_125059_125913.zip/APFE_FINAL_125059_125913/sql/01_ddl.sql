CREATE TABLE Utilizador (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	PrimeiroNome VARCHAR(16) NOT NULL,
	Apelido VARCHAR(16) NOT NULL,
	Email VARCHAR(16) NOT NULL,
	Senha VARCHAR(16) NOT NULL,
	País VARCHAR(16) NOT NULL,
	Nacionalidade VARCHAR(16) NOT NULL,
	DataDeNascimento VARCHAR(16) NOT NULL
);

CREATE TABLE Equipa (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Orçamento Float(16) NOT NULL,
	Nome VARCHAR(16) NOT NULL,
	PontuaçãoTotal VARCHAR(16) NOT NULL,
	ID_utilizador VARCHAR(8) NOT NULL,

	FOREIGN KEY (ID_utilizador)
		REFERENCES Utilizador(ID)
);

CREATE TABLE Clube (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Nome VARCHAR(16) NOT NULL,
	País VARCHAR(16) NOT NULL
);

CREATE TABLE Estado_Jogador (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Estado VARCHAR(16) NOT NULL
);

CREATE TABLE Jogador (

	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Nome VARCHAR(16) NOT NULL,
	Posição VARCHAR(16) NOT NULL,
	Preço Float(16) NOT NULL,
	ID_clube VARCHAR(8) NOT NULL,
	ID_Estado_Jogador VARCHAR(8) NOT NULL,

	FOREIGN KEY (ID_clube)
		REFERENCES Clube(ID),

	FOREIGN KEY (ID_Estado_Jogador)
		REFERENCES Estado_Jogador(ID)
);

CREATE TABLE Tipo_Liga (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Tipo VARCHAR(16) NOT NULL,
	Código VARCHAR(8) NOT NULL
);

CREATE TABLE Liga (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Nome VARCHAR(16) NOT NULL,
	Data_Inicio VARCHAR(16) NOT NULL,
	Data_Fim VARCHAR(16) NOT NULL,
	ID_tipoLiga VARCHAR(8) NOT NULL,
	ID_criador VARCHAR(8) NOT NULL,

	FOREIGN KEY (ID_criador)
		REFERENCES Utilizador(ID),
    FOREIGN KEY (ID_tipoLiga)
        REFERENCES Tipo_Liga(ID)
);

CREATE TABLE Jornada (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Data_Inicio VARCHAR(16) NOT NULL,
	Data_Fim VARCHAR(16) NOT NULL,
	Numero INT NOT NULL,
	ID_liga VARCHAR(8) NOT NULL,

	FOREIGN KEY (ID_liga)
		REFERENCES Liga(ID)

);

CREATE TABLE Pontuação_Equipa (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	ID_equipa VARCHAR(8) NOT NULL,
	ID_jornada VARCHAR(8) NOT NULL,
	Pontuação_Jornada INT NOT NULL,

	FOREIGN KEY (ID_equipa)
		REFERENCES Equipa(ID),

	FOREIGN KEY (ID_jornada)
		REFERENCES Jornada(ID)
)

CREATE TABLE Pontuação_Jogador (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	ID_jogador VARCHAR(8) NOT NULL,
	ID_jornada VARCHAR(8) NOT NULL,
	TempoJogo INT NOT NULL,
    GolosSofridos INT DEFAULT 0,
    Pontuacao_Jornada INT NOT NULL,
    Assistencias INT DEFAULT 0,
    CartoesAmarelos INT DEFAULT 0,
    CartoesVermelhos INT DEFAULT 0,

	FOREIGN KEY (ID_jogador)
		REFERENCES Jogador(ID),

	FOREIGN KEY (ID_jornada)
		REFERENCES Jornada(ID)
)

CREATE TABLE Jogo (
	ID VARCHAR(8) NOT NULL PRIMARY KEY,
	[Data] VARCHAR(16) NOT NULL,
	ID_Clube1 VARCHAR(8) NOT NULL,
	ID_CLube2 VARCHAR(8) NOT NULL,
	ID_jornada VARCHAR(8) NOT NULL,

	FOREIGN KEY (ID_Clube1)
		REFERENCES Clube(ID),

	FOREIGN KEY (ID_Clube2)
		REFERENCES Clube(ID),

	FOREIGN KEY (ID_jornada)
		REFERENCES Jornada(ID)
)

CREATE TABLE Pertence (
    ID_Jogador VARCHAR(8) NOT NULL,
    ID_Equipa VARCHAR(8) NOT NULL,
    PRIMARY KEY (ID_Jogador, ID_Equipa),
    FOREIGN KEY (ID_Jogador) REFERENCES Jogador(ID),
    FOREIGN KEY (ID_Equipa) REFERENCES Equipa(ID)
);

CREATE TABLE Participa (
    ID_Utilizador VARCHAR(8) NOT NULL,
    ID_Liga VARCHAR(8) NOT NULL,
    PRIMARY KEY (ID_Utilizador, ID_Liga),
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID),
    FOREIGN KEY (ID_Liga) REFERENCES Liga(ID)
);

CREATE TABLE Enfrenta (
	ID_Jogo VARCHAR(8) NOT NULL,
	ID_Clube1 VARCHAR(8) NOT NULL,
	ID_Clube2 VARCHAR(8) NOT NULL

	FOREIGN KEY (ID_JOGO)
		REFERENCES Jogo(ID),

	FOREIGN KEY (ID_Clube1)
		REFERENCES Clube(ID),

	FOREIGN KEY (ID_CLube2)
		REFERENCES Clube(ID)
)